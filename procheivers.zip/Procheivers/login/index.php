<?php
  include 'config.php';
  session_start();
  error_reporting(0);
  $mailtosend;
  if (isset($_POST["signup"])) 
  {
    $first_Name = mysqli_real_escape_string($conn, $_POST["first-name"]);
    $last_Name = mysqli_real_escape_string($conn, $_POST["last-name"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $contact_Number = mysqli_real_escape_string($conn, $_POST["contact-number"]);
    $user_type = mysqli_real_escape_string($conn, $_POST["user-type"]);
    $password = mysqli_real_escape_string($conn, ($_POST["sign-up-password"]));
    $cpassword = mysqli_real_escape_string($conn, ($_POST["cpassword"]));
    $mailtosend = $email;
    
    $check_email = mysqli_num_rows(mysqli_query($conn, "SELECT email FROM login_register_form WHERE email='$email'"));
    if ($password != $cpassword) 
    {
      echo "<script>alert('Password did not match.');</script>";
    } elseif ($check_email > 0) 
    {
      echo "<script>alert('Email already exists in out database.');</script>";
    }else 
    {
      $sql = "INSERT INTO login_register_form (fName, lName, email, contact_Number, user_type,password) VALUES ('$first_Name', ' $last_Name', '$email', '$contact_Number', '$user_type','$password')";
      $result = mysqli_query($conn, $sql);

      $message='Congratulations!!! You have been registered succesfully';
      include_once("SMTP/class.phpmailer.php");
      include_once("SMTP/class.smtp.php");
      // $email = $email; 
      $mail = new PHPMailer;
      $mail->IsSMTP();
      $mail->SMTPAuth = true;                 
      $mail->SMTPSecure = "tls";      
      $mail->Host = 'smtp.gmail.com';
      $mail->Port = 587; 
      $mail->Username = "procheiver0210@gmail.com";   //Enter your username/emailid
      $mail->Password = "ajyuebsfxjzrrdvn";   //Enter your password
      $mail->FromName = "Procheivers";
      $mail->AddAddress($mailtosend);
      $mail->Subject = "Your Registration Is Confirmed";
      $mail->isHTML( TRUE );
      $mail->Body =$message;
      if($mail->send())
        {
          echo '<script>alert("Please check your mail to see the confirm message!")</script>';
        }
        else
        {
          echo '<script>alert("We can`t find a user with that email address")</script>';
        }

      if($result)
      {
        $_POST["first_Name"] = "";
        $_POST["last_Name"] = "";
        $_POST["email"] = "";
        $_POST["contact_Number"] = "";
        $_POST["user_type"] = "";
        $_POST["password"] = "";
        echo "<script>alert('user resgister successfully');windows.location='index.php';</script>";
      }
      else
      {
        echo "<script>alert('user resgister failed')</script>";
      }
    }     
  }

  if(isset($_SESSION['isUserLoggedin']))
  {
    if($_SESSION['usertype']== "Examiner")
    {
        echo "<script>window.location.href='Examiner/examinerh.php?user_already_logged_in';</script>";
    } 
    if($_SESSION['usertype']== "Student")
    {
      echo "<script>window.location.href='Student/student.php?user_already_logged_in';</script>";
    } 
  }
  if (isset($_POST["signin"])) 
  {

    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = mysqli_real_escape_string($conn, ($_POST["password"]));
    $query = "SELECT * FROM login_register_form WHERE email='$email' AND password='$password'";
    $run = mysqli_query($conn, $query);
    $data = mysqli_fetch_array($run);
    if($data)
    {
      if(count($data) > 0)
      {
        $_SESSION['isUserLoggedin'] = true;
        $_SESSION['emailId']= $email;
        $_SESSION['usertype']= $data['user_type'];
        // $_SESSION['user_id'] = $data['id'];

        if($data['user_type'] == "Examiner"){
          echo "<script>window.location.href='Examiner/examinerh.php?user_loggedin'</script>";
        }
        if($data['user_type'] == "Student"){
          echo "<script>window.location.href='Student/student.php?user_loggedin'</script>";
        }
      }
      else
      {
        echo "<script>'window.location.href='index.php?incorrect_email_or_password';</script>";
      }
    }
    else{
      echo "<script>alert('Email or Password Incorrect. Kindly Provide Right Details!!'); window.location.href='index.php?incorrect_email_or_password';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style.css" />
  <title>Sign in & Sign up Form</title>
</head>
<body>
  <div class="container">
    <div class="forms-container">
      <div class="signin-signup">
        <form action="" class="sign-in-form" method="post">
          <!-- login form -->
          <h2 class="title">Sign in</h2>
          <div class="input-field">
            <i class="fas fa-user"></i>
            <input type="text" placeholder="Email Address" name="email" value="<?php echo $_POST['email'];?>" required/>
          </div>
          <div class="input-field">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password'];?>" required/>
          </div>
          <p>Forgot Your Password No worry?<a href="recovery_email.php">Click Here</a></p>
          <input type="submit" value="Login" class="btn solid" name="signin"/>
        </form>

        <!-- register form -->
        <form action="" class="sign-up-form" method="post"> 
          <h2 class="title">Sign up</h2>
          <div class="input-field">
            <i class="fas fa-user"></i>
            <input type="text" placeholder="First Name" name="first-name" required/>
          </div>
          <div class="input-field">
            <i class="fas fa-user"></i>
            <input type="text" placeholder="Last Name" name="last-name" required/>
          </div>
          <div class="input-field">
            <i class="fas fa-address-book"></i>
            <input type="text" placeholder="Contact Number" name="contact-number" required/>
          </div>
          <div class="input-field">
            <i class="fas fa-envelope"></i>
            <input type="email" placeholder="Email" name="email" required/>
          </div>
          <div class="input-field">
            <i class="fas fa-caret-down"></i>
            <select name="user-type" id="user-type" required>
              <option value="" ><b> --Select user-- </b></option>
              <option value="Examiner"><b>Examiner</b></option>
              <option value="Student"><b>Student</b></option>
            </select>
          </div>
          <div class="input-field">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Password" name="sign-up-password" required/>
          </div>
          <div class="input-field">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Confirm Password" name="cpassword" required/>
          </div>
          <input type="submit" class="btn" name="signup" value="Sign up" required/>
        </form>
      </div>
    </div>

    <div class="panels-container">
      <div class="panel left-panel">
        <div class="content">
          <h3>New here ?</h3>
          <p>Register Your Account Now</p>
          <button class="btn transparent" id="sign-up-btn">Sign up</button>
        </div>
        <img src="img/log.gif" class="image" alt="" />
      </div>
      <div class="panel right-panel">
        <div class="content">
          <h3>One of us ?</h3>
          <p>Login Your Account Now!</p>
          <button class="btn transparent" id="sign-in-btn">Sign in</button>
        </div>
        <img src="img/register.gif" class="image" alt="" />
      </div>
    </div>
  </div>
  <script src="app.js"></script>
</body>
</html>