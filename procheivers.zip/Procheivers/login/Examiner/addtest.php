<?php 
    include 'config.php';
    include 'dashboard.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Quiz</title>
  
  <link href="addtest.css" rel="stylesheet"/>
  <!-- <link href="addcat.css" rel="stylesheet" /> -->
  <!-- <link rel="stylesheet" href="dashboard.css" /> -->
  <!-- <link rel="stylesheet" href="addtest.css?v=<?php echo time(); ?>"> -->
  <!-- <link rel="stylesheet" href="addcat.css?v=<?php echo time(); ?>"> -->
  <link rel="stylesheet" href="dashboard.css?v=<?php echo time(); ?>">
  <!-- <link rel="stylesheet" href="addcat.css"> -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
</head>
<body>
  <section class="home-section">
    <div class="home-content">
      <i class="bx bx-menu"></i>
      <span class="text">Add Quiz</span>
    </div>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="examinerh.php">Home</a></li>
        <li class="breadcrumb-item"><a href="addtest.php">Add Quiz</a></li>
        <li class="breadcrumb-item active">Add Quiz</li>
      </ol>
    </nav>
    <div class="container select-box">
        <div class="container head ">
            <span>Add Test</span>
            <button type="button" class="btn btn-primary addbtn" data-bs-toggle="modal" data-bs-target="#myModal" >ADD</button>
        </div>
    </div>
    <div class="modal fade" id="myModal">
      <div class="modal-dialog">
        <div class="modal-content">

          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Add Test</h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>

          <!-- Modal body -->
          <div class="modal-body">
            <form action="addtestquery.php" method="POST">
              <div class="form-group">
                <label for="name">Quiz Name:</label>
                <input type="text" name="quiz-name" class="form-control" placeholder="name your test">
              </div>  
              <?php 
                $query ="SELECT * FROM categories";
                $result = $conn->query($query);
                if($result->num_rows> 0)
                {
                  $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                }
              ?>
              <div class="form-group">
                <label for="categories">Choose Category:</label>
              </div>
              <div class="form-group">
                <select name="categories" id="categories" class="form-select">
                  <option hidden>Select Category</option>
                    <?php 
                      foreach ($options as $option) 
                      {
                        ?>
                            <option><?php echo $option['D_name']; ?> </option>
                            <?php 
                      }
                    ?>
                </select>
              </div>
              <?php 
                $query ="SELECT sub_name FROM subjects";
                $result = $conn->query($query);
                if($result->num_rows> 0)
                {
                  $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                }
              ?>
              <div class="form-group">
                <label for="subjects">Choose Subject:</label>
              </div>
              <div class="form-group">
                <select name="subjects" id="subjects" class="form-select">
                  <option hidden>Select Subject</option>
                    <?php 
                      foreach ($options as $option) 
                      {
                    ?>
                    <option><?php echo $option['sub_name']; ?> </option>
                    <?php 
                      }
                    ?>
                </select>
              </div>
              <div class="form-group">
                <label for="name">Total Test Duration:</label>
                <!-- <input type="text" name="quiz-name" class="form-control" placeholder="name your test"> -->
              </div>
              <div class="form-group">
                <select name="total_test_duration" id="total_test_duration" class="form-select">
                  <!-- <?php
                    for ($i=1; $i<=30; $i++)
                      {
                          ?>
                              <option value="none" selected disabled hidden>Select an Option</option>
                              <option value="<?php echo $i;?>"><?php echo $i;?></option>
                          <?php
                      }
                  ?> -->
                  <option value="none" selected disabled hidden>Select an Option</option>
                  <option value="30">30 second</option>
                  <option value="60">1 minutes</option>
                  <option value="90">1 minutes 30 second</option>
                  <!-- <option value="7200">2hr : 00 mins</option>
                  <option value="9000">2hr : 30 mins</option> -->
                </select>
              </div>
              <div class="form-group">
                <label for="name">Total Test Marks:</label>
                <!-- <input type="text" name="quiz-name" class="form-control" placeholder="name your test"> -->
              </div>
              <div class="form-group">
                <select name="total_test_marks" id="total_test_marks" class="form-select">
                  <?php
                    for ($i=1; $i<=30; $i++)
                    {
                  ?>
                  <option value="none" selected disabled hidden>Select an Option</option>
                  <option value="<?php echo $i;?>"><?php echo $i;?></option>
                  <?php
                    }
                  ?>
                </select>
              </div>
              <!-- Modal footer -->
              <div class="modal-footer">
                <button type="submit" name="save_test" class="btn btn-success" data-bs-dismiss="modal">Add</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- showlist added quiz name  -->
    <div class="container showlist">
      <div class="container-fluid list-data table-responsive mt-5">
        <table class="table table-hover table-bordered">
          <thead>
            <tr>
              <th>Quiz Name</th>
              <th>Category Name</th>
              <th>Subject Name</th>
              <th>Total_Test_Duration</th>
              <th>Total_test_marks</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php
            
              $per_page = 5;
              $start = 0;
              $current_page=1;
              if(isset($_GET['start']))
              {
                $start=$_GET['start'];
                if($start<=0){
                  $start=0;
                  $current_page=1;
                }else{
                  $current_page=$start;
                  $start--;
                  $start=$start*$per_page;
                }
              }
              $record = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM quiz_name"));

              $num_per_page = 05;
              $pagi=ceil($record/$per_page);
              $sql = "SELECT * FROM quiz_name LIMIT $start, $per_page";
              $result = mysqli_query($conn, $sql);

              if(mysqli_num_rows($result)>0)
              {
                  foreach($result as $item){
                      ?>
                      <tr>
                          <td><?= $item['quiz_name'] ?></td>
                          <td><?= $item['D_name'] ?></td>
                          <td><?= $item['sub_name']?></td>
                          <td><?= $item['Total_test_duration'] ?></td>
                          <td><?= $item['Total_test_marks']?></td>
                          <td>
                            <form action="" method="POST">
                              <a
                                href="deletesubjects.php?id=<?= $item['quiz_id'];?>&name=<?= $item['quiz_name'];?>"
                                class="btn btn-danger"
                              >
                              Delete
                              </a>
                            </form>
                            
                            </td>   
                      </tr>
                      <?php
                  }
              }
              else
              {
                  ?>
                  <tr>
                      <td colspan="5">No record found!!</td>
                  </tr>
                  <?php
              }

            ?>
          </tbody>
        </table>
        <!-- pagination code -->
        <ul class="pagination pagination-lg  justify-content-center">
          <?php 
            for($i=1;$i<=$pagi;$i++)
            {
              $class='';
              if($current_page==$i)
              {
                ?><li class="page-item active"><a class="page-link" href="javascript:void(0)"><?php echo $i?></a></li><?php
              }else
              {
                ?>
                <li class="page-item"><a class="page-link" href="?start=<?php echo $i?>"><?php echo $i?></a></li>
                <?php
              }
              ?>
              
              <?php
            } 
          ?>
        </ul>
      </div>
    </div>
  </section>
  <script src="script.js"></script>
</body>
</html>