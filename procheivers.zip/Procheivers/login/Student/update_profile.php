<?php
    include "config.php";
    session_start();
    $id = $_SESSION['user_id'];
    $statusMsg = '';

    // File upload path
    $targetDir = "assets/img/";
    $fileName = basename($_FILES["file"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
    $fName = $_POST['fName'];
    $lName = $_POST['lName'];
    $email = $_POST['email'];
    $contact = $_POST['contact_number'];

    if(isset($_POST["submit"]) )
    {
        // && !empty($_FILES["file"]["name"])
        if(!empty($_FILES["file"]["name"]))
        {
           

                // Allow certain file formats
            $allowTypes = array('jpg','png','jpeg','gif','pdf');

            if(in_array($fileType, $allowTypes))
            {
                // Upload file to server
                if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath))
                {
                    // Insert image file name into database
                    // $insert = $conn->query("INSERT into admin_login ( file_name, uploaded_on) VALUES ('".$fileName."' , NOW())" );
                    $insert = $conn->query("UPDATE login_register_form SET file_name = '$fileName', uploaded_on = NOW(), email = '$email', fName = '$fName' , lName = '$lName', contact_Number = '$contact'  WHERE id = $id ;");
                    
                    if($insert)
                    {
                        $statusMsg = "Profile details Updated successfully.";
                    }else
                    {
                        $statusMsg = "File upload failed, please try again.";
                    } 
                }else
                {
                    $statusMsg = "Sorry, there was an error uploading your file.";
                }
            }else
            {
                $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
            }
        }else
        {
            $insert_for_nonimg = $conn->query("UPDATE admin_login SET email = '$email', fName = '$fName' , lName = '$lName' WHERE id = 1 ;");
            if($insert_for_nonimg){
                $statusMsg = "Profile details Updated successfully for just text.";
            }else{
                $statusMsg = "File upload failed, please try again. fpr just text";
            } 
            //$statusMsg = 'Please select a file to upload.';
        }
        echo "<script>alert('".$statusMsg."'); location.href='users-profile.php';</script>";
    }
    // Display status message
?>
