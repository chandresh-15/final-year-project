<html>
<body>
    <?php
        include "config.php";
        if(isset($_GET['id']))
        {
            $quiz_id = $_GET['id'];
            $qui_name = $_GET['name'];

            $sql = "DELETE FROM quiz_name WHERE quiz_id = '$quiz_id'";
            $res = "DROP TABLE `$qui_name`";
            mysqli_query($conn, $res);
            $result = mysqli_query($conn, $sql);
        }
        if($result)
        {
            echo "<script>alert('Quiz deleted successfully'); window.location = 'addtest.php'</script>";

        }
        else
        {
            echo "<script>alert('Facing an Error Please Try Again!!'); window.location = 'addtest.php'</script>";

        }   
    ?>
</body>
</html>