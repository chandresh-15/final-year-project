<?php
    $hostname = "localhost";
    $username = "examportal";
    $password = "Exam@1234";
    $database = "myexamportal";
    $conn = mysqli_connect($hostname, $username, $password, $database) or die("Database connection failed");
?>