<?php
    include "config.php";

    if(isset($_POST['save_test'])){
        $test_name = $_POST['quiz-name'];
        $test_name_new = $test_name;
        $category = $_POST['categories'];
        $subject = $_POST['subjects'];
        $total_test_duration = $_POST['total_test_duration'];
        $total_test_marks = $_POST['total_test_marks'];

        mysqli_query($conn,"CREATE TABLE `$test_name_new` (quiz_id INT(50) AUTO_INCREMENT PRIMARY KEY,quiz_name VARCHAR(100) NOT NULL, questions VARCHAR(255) NOT NULL, option_1 VARCHAR(50) NOT NULL, option_2 VARCHAR(50) NOT NULL, option_3 VARCHAR(50) NOT NULL, option_4 VARCHAR(50) NOT NULL, correct_option VARCHAR(50) NOT NULL, each_question_marks INT(50));");
        print("table created");

        $query = "INSERT INTO quiz_name (quiz_name,D_name,sub_name,Total_test_duration,Total_test_marks) VALUES('$test_name','$category','$subject','$total_test_duration','$total_test_marks')";
        $query_run  = mysqli_query($conn,$query);

        if($query_run){
            echo "<script>alert('Quiz Created successfully') ;  window.location.replace('addtest.php')</script>";
        }
        else{
            echo "<script>alert('Please try again later!!') ;  window.location.replace('addtest.php')</script>";
        }
    }

?>