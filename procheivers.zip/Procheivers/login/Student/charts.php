<?php
  include 'Student_dashboard.php';
   //$conn = mysqli_connect("localhost","examportal","Exam@1234","charts");
  include 'config.php';

?>

<html>
<head>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() 
    {
      var data = google.visualization.arrayToDataTable([
          ['quiz_name', 'marks_obtained','quiz_id'],
        <?php
          $user_id_chart =  $_SESSION['user_id'];
          $sql = "SELECT * FROM result WHERE user_id=$user_id_chart";
          $fire = mysqli_query($conn,$sql);
          while($result = mysqli_fetch_assoc($fire)){
            echo"['".$result['quiz_name']. "',".$result['marks_obtained'].",".$result['quiz_id']."],";
          }
        ?>
      ]);

      var options = {
        title: 'OverAll Performance',
        is3D: true,
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
      chart.draw(data, options);
    }
  </script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <section class="home-section">
    <div class="home-content">
      <i class="bx bx-menu"></i>
      <span class="text">Graphical Representation</span>
    </div>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="student.php">Home</a></li>
        <li class="breadcrumb-item"><a href="charts.php">Graphical Representation</a></li>
        <li class="breadcrumb-item active">Graphical Representation</li>
      </ol>
    </nav>
    <div id="piechart_3d" style="width: auto; height: 100vh;"></div>
  </section>
  <script src="script.js"></script>
</body>
</html>