 <?php
    include "config.php";

    if(isset($_POST['save_questions'])){
        $quiz_name = $_POST['quiz_name'];
        // $quiz_name_new = $quiz_name;
        $questions = $_POST['question'];
        $option1 = $_POST['option1'];
        $option2 = $_POST['option2'];
        $option3 = $_POST['option3'];
        $option4 = $_POST['option4'];
        $correct_option = $_POST['correct_option'];
        $each_question_marks = $_POST['each_question_marks'];

        // mysqli_query($conn,"CREATE TABLE $quiz_name ( quiz_name VARCHAR(50) NOT NULL, questions VARCHAR(50) NOT NULL, option_1 VARCHAR(50) NOT NULL), option_2 VARCHAR(50) NOT NULL), option_3 VARCHAR(50) NOT NULL), option_4 VARCHAR(50) NOT NULL), correct_option VARCHAR(50) NOT NULL)");
        // print("table created"); 
        
        $addquery = "INSERT INTO  `$quiz_name` (quiz_name,questions,option_1,option_2,option_3,option_4,correct_option,each_question_marks) VALUES('$quiz_name','$questions','$option1','$option2','$option3','$option4','$correct_option','$each_question_marks')";
        $query_run  = mysqli_query($conn,$addquery);

        if($query_run)
        {
            echo "<script>alert('Question added successfully') ;  window.location.replace('questions.php')</script>";
        }
        else
        {
            echo "<script>alert('Please try again !!') ;  window.location.replace('questions.php')</script>";
        }
    }

?>