<?php
  //session_start();
     include "config.php";
     include "dashboard.php";
      // session_start();
     $id = $_SESSION['user_id'];
    //  echo $examiner_email;
    $query = "SELECT * FROM login_register_form WHERE id =  '$id' ";
    $result_Examiner = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Setting</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <!-- Template Main CSS File -->
  <!-- <link href="assets/css/style.css" rel="stylesheet"> -->
  <!-- jquery link diya hai just for img  -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
  <section class="home-section">
    <main id="main" class="main">
      <div class="home-content">
        <i class="bx bx-menu"></i>
        <span class="text">User Profile</span>
      </div>
      <!-- <main id="main" class="main"> -->
      <div class="pagetitle">
        
        <nav>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="examinerh.php">Home</a></li>
            <li class="breadcrumb-item"><a href="users-profile.php">Profile</a></li>
            <li class="breadcrumb-item active">Profile</li>
          </ol>
        </nav>
      <!-- End Page Title -->
      </div>
      <section class="section profile">
        <div class="row">
          <div class="col-xl-4">
            <?php
              while($row = mysqli_fetch_array($result_Examiner))
              {
                //$imageurl = "assets/img/".$row["file_name"];
                $finalpath_for_img;

                if($row["file_name"] == null){
                  $finalpath_for_img = "./assets/img/profile-img.jpg";
                }
                else{
                  $imageurl = "assets/img/".$row["file_name"];
                  $finalpath_for_img = $imageurl;
                }
            ?>
            <div class="card">
              <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
              <img src="<?php echo $finalpath_for_img;?>" alt="Profile" class="rounded-circle image_class" style="width : 199px; height: 190px;">
              <h2><?php echo $row["fName"],  $row["lName"]; ?></h2>
              <h3><?php echo $row["user_type"];?></h3>
              <div class="social-links mt-2">
                <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xl-8">
          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">
                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-settings">Settings</button>
                </li>
              </ul>

              <div class="tab-content pt-2">
                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                  <h5 class="card-title">Profile Details</h5>
                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">User ID</div>
                    <div class="col-lg-9 col-md-8"><?php echo $row['id']?></div>
                  </div>
                  <div class="row">
                    <div class="col-lg-3 col-md-4 label ">Full Name</div>
                    <div class="col-lg-9 col-md-8"><?php echo $row['fName'], $row['lName']; ?></div>
                  </div>
                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">User Type</div>
                    <div class="col-lg-9 col-md-8"><?php echo $row['user_type']?></div>
                  </div>
                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Email</div>
                    <div class="col-lg-9 col-md-8"><?php echo $row['email']?></div>
                  </div>
                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Contact Number</div>
                    <div class="col-lg-9 col-md-8"><?php echo $row['contact_Number'] ?></div>
                  </div>
                </div>
              
                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                  <!-- Profile Edit Form -->
                  <form action="update_profile.php" method="post" enctype="multipart/form-data">
                    <div class="row mb-3">
                      <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Profile Image</label>
                      <div class="col-md-8 col-lg-9">
                        <img class="image_class " src="<?php echo $finalpath_for_img;?>" alt="Profile"  style="width : 220px; height: 170px;">
                        <div class="pt-2">
                          <label for="buttonforupload" ><i class="btn btn-primary btn-sm bi bi-upload"></i></label>
                          <!-- <a href="#" class="btn btn-primary btn-sm" title="Upload new profile image"><i class="bi bi-upload"></i></a> -->
                          <input type="file" name="file" id="buttonforupload" style="display: none; visibility:none;" onchange="getImage(this);" />
                          <a class="btn btn-danger btn-sm" title="Remove my profile image"><button type="button" style="background-color: transparent; color:white; border: none;" onclick="myFunction()" ><i class="bi bi-trash"></i></button></a>
                        </div>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="fName" class="col-md-4 col-lg-3 col-form-label">First Name</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="fName" type="text" class="form-control" id="fName" value="<?php echo $row['fName']; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="lName" class="col-md-4 col-lg-3 col-form-label">Last Name</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="lName" type="text" class="form-control" id="lName" value="<?php echo $row['lName']; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="email" type="text" class="form-control" id="email" value="<?php echo $row['email'] ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Country" class="col-md-4 col-lg-3 col-form-label">Contact Number</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="contact_number" type="text" class="form-control" id="contact_number" value="<?php echo $row['contact_Number'];?>">
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" name="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form><!-- End Profile Edit Form -->

                </div>
                <?php
                  }
                ?>

                <div class="tab-pane fade pt-3" id="profile-settings">
                  <!-- Settings Form -->
                  <form>
                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Email Notifications</label>
                      <div class="col-md-8 col-lg-9">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                          <label class="form-check-label" for="changesMade">
                            Changes made to your account
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="newProducts" checked>
                          <label class="form-check-label" for="newProducts">
                            Information on new products and services
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="proOffers">
                          <label class="form-check-label" for="proOffers">
                            Marketing and promo offers
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="securityNotify" checked disabled>
                          <label class="form-check-label" for="securityNotify">
                            Security alerts
                          </label>
                        </div>
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form><!-- End settings Form -->
                </div>
              </div><!-- End Bordered Tabs -->
            </div>
          </div>
        </div>
      </section>

     <!-- <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> -->
                
    </main>
    <!-- </main>End #main -->
  </section>
 

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <!-- <script src="assets/js/main.js"></script> -->

  <!-- script to retrive image -->
  <script>
    function getImage(input)
    {
      $('.image_class')[0].src = (window.URL ? URL : webkitURL).createObjectURL(input.files[0]);
     //var newimg = imagename.replace(/^.*\\/,"");
      // console.log(newimg)
      // document.querySelector(".image_class").src = <?php //echo $imageurl;?> ;
      // document.querySelector(".image_class1").src = <?php //echo $imageurl;?>;
    }

    function myFunction() 
    {
      let text = "Are your sure you want to delete image";
      if (confirm(text) == true) {
        location.href='deleteprofileimg.php';
      } else {
        location.href="users-profile.php";
      }
    }
  </script>
  <!-- for toggle the menu bar -->
  <script src="script.js"></script>
</body>
</html>