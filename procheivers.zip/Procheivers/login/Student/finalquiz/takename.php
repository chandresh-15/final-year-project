<?php
     include "config.php";
     $quiz_name =  $_POST['quiz_name'];
    
     $sql = "SELECT * FROM `$quiz_name`";
    $res = mysqli_query($conn, $sql);
    $val = mysqli_fetch_all($res, MYSQLI_ASSOC);
    //  $val1 = json_encode($val);

     echo json_encode($val);
?>