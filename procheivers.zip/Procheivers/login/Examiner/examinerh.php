<?php
  include "config.php";
  include 'dashboard.php'; 
  //  session_start();
  if(!isset($_SESSION['isUserLoggedin']))
  {
      echo "<script>window.location.href='index.php?user_not_logged_in';</script>";
  }
  if($_SESSION['usertype']!= 'Examiner')
  {
      echo "<script>window.location.href='index.php';</script>";
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>Procheivers</title>
    <link rel="stylesheet" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet"/>
    <script src="https://kit.fontawesome.com/aa64bf530b.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  </head>
  <?php
   
    $con = mysqli_connect("localhost","examportal","Exam@1234","myexamportal");
  ?>
  <body>
    <section class="home-section">
      <div class="home-content">
        <i class="bx bx-menu"></i>
        <span class="text">Dashboard</span>
      </div>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="examinerh.php">Home</a></li>
          <li class="breadcrumb-item active">Home</li>
        </ol>
      </nav>
      <div class="dash-top">
        <h2>
          Dashboard
        </h2>
        <span>
          Application data
        </span>
      </div> 
      <div class="container mt-5">
        <!--box-1-->
        <div class="row">
          <div class="col-md-3">
            <div class="card text-center">
              <div class="card-header bg-primary text-white">
                <div class="row align-items-center">
                  <div class="col">
                    <i class="fa fa-list fa-4x"></i>
                  </div>
                  <div class="col">
                    <?php 
                      $dash_category_query = "SELECT * from categories";
                      $dash_category_query_run = mysqli_query($con,$dash_category_query);

                      if($category_total = mysqli_num_rows($dash_category_query_run))
                      {
                        echo '<h3 class="display-3">'.$category_total.'</h3>';
                      }
                      else
                      {
                        echo '<h3 class="display-3">No Data</h3>';
                      }
                    ?>
                    <h6>Categories</h6>
                  </div>
                </div>
              </div>
              <div class="card-footer">
                <h5>
                  <a href="#" class="text-primary">View Details <i class="fa-regular fa-circle-right"></i></a>
                </h5>
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <div class="card text-center">
              <div class="card-header bg-primary text-white">
                <div class="row align-items-center">
                  <div class="col">
                    <i class="fa fa-list fa-4x"></i>
                  </div>
                  <div class="col">
                  <?php 
                    $dash_subject_query = "SELECT * from subjects";
                    $dash_subject_query_run = mysqli_query($con,$dash_subject_query);
                    if($subject_total = mysqli_num_rows($dash_subject_query_run))
                    {
                      echo '<h3 class="display-3">'.$subject_total.'</h3>';
                    }
                    else
                    {
                      echo '<h3 class="display-3">No Data</h3>';
                    }
                  ?>
                  <h6>Subjects</h6>
                </div>
              </div>
            </div>
            <div class="card-footer">
              <h5>
                <a href="#" class="text-primary">View Details <i class="fa-regular fa-circle-right"></i></a>
              </h5>
            </div>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card text-center">
            <div class="card-header bg-primary text-white">
              <div class="row align-items-center">
                <div class="col">
                  <i class="fa fa-list fa-4x"></i>
                </div>
                <div class="col">
                  <?php 
                    $dash_user_query = "SELECT * from login_register_form where user_type='student'";
                    $dash_user_query_run = mysqli_query($con,$dash_user_query);
                    if($user_total = mysqli_num_rows($dash_user_query_run))
                    {
                      echo '<h3 class="display-3">'.$user_total.'</h3>';
                    }
                    else
                    {
                      echo '<h3 class="display-3">No Data</h3>';
                    }
                  ?>
                  <h6>Total Users</h6>
                </div>
              </div>
            </div>
            <div class="card-footer">
            <h5>
              <a href="#" class="text-primary">View Details <i class="fa-regular fa-circle-right"></i></a>
            </h5>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card text-center">
          <div class="card-header bg-primary text-white">
            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-list fa-4x"></i>
              </div>
              <div class="col">
                <?php 
                      $dash_admin_query = "SELECT * from admin_login";
                      $dash_admin_query_run = mysqli_query($con,$dash_admin_query);

                      if($admin_total = mysqli_num_rows($dash_admin_query_run))
                      {
                        echo '<h3 class="display-3">'.$admin_total.'</h3>';
                      }
                      else
                      {
                        echo '<h3 class="display-3">No Data</h3>';
                      }
                  ?>
                  <h6>Admin</h6>
                </div>
              </div>
            </div>
            <div class="card-footer">
              <h5>
                <a href="#" class="text-primary">View Details <i class="fa-regular fa-circle-right"></i></a>
              </h5>
            </div>
          </div>
        </div>

        <div class="col-md-3 mt-5">
          <div class="card text-center">
            <div class="card-header bg-primary text-white">
              <div class="row align-items-center">
                <div class="col">
                  <i class="fa fa-list fa-4x"></i>
                </div>
                <div class="col">
                <?php 
                  $dash_examiner_query = "SELECT * from login_register_form where user_type='examiner'";
                  $dash_examiner_query_run = mysqli_query($con,$dash_examiner_query);

                  if($examiner_total = mysqli_num_rows($dash_examiner_query_run))
                  {
                    echo '<h3 class="display-3">'.$examiner_total.'</h3>';
                  }
                  else
                  {
                    echo '<h3 class="display-3">No Data</h3>';
                  }
                ?>
                <h6>Examiners</h6>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h5>
              <a href="#" class="text-primary">View Details <i class="fa-regular fa-circle-right"></i></a>
            </h5>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="script.js"></script>
</body>
</html>
