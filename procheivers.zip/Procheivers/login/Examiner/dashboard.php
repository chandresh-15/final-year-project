<?php
  include "config.php";
  session_start();
  $examiner_email = $_SESSION['emailId'];
  //  echo $examiner_email;
  $query = "SELECT * FROM login_register_form WHERE email = '$examiner_email'";
  $result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8" />
  <title>Examiner</title>
  <link rel="stylesheet" href="dashboard.css" />
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet"/>   
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
  <div class="sidebar close">
    <div class="logo-details">
      <!-- <i class="bx bxl-c-plus-plus"></i> -->
      <i class='bx bxs-book-reader'></i> 
      <span class="logo_name">Procheivers</span>
      <!-- <span><img src="logo-color.png" width="120px" height="50px"></span> -->
    </div>
    <ul class="nav-links">
      <li>
        <a href="examinerh.php">
          <i class="bx bx-grid-alt"></i>
          <span class="link_name">Home</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Home</a></li>
        </ul>
      </li>
      <li>
        <a href="addtest.php">
          <i class='bx bx-book-content'></i>
          <span class="link_name">Create Quiz</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Create Quiz</a></li>
        </ul>
      </li>
      <li>
        <a href="questions.php">
          <i class="bx bx-pie-chart-alt-2"></i>
          <span class="link_name">Add Questions</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Add Questions</a></li>
        </ul>
      </li>
      <!-- <li>
        <a href="charts.php">
          <i class="bx bx-line-chart"></i>
          <span class="link_name">Chart</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Chart</a></li>
        </ul>
      </li> -->
      <li>
        <a href="ranktable.php">
          <i class="bx bx-history"></i>
          <span class="link_name">Rank Table</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Rank Table</a></li>
        </ul>
      </li>
      <li>
        <a href="users-profile.php">
          <i class="bx bx-cog"></i>
          <span class="link_name">Profile</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Profile</a></li> 
        </ul>
      </li>
      <?php
        while($row = mysqli_fetch_array($result)){
        $_SESSION['user_id']= $row['id'];
        // $imageurl = "assets/img/".$row["file_name"];
        $finalpath_for_img;
        if($row["file_name"] == null){
          $finalpath_for_img = "./assets/img/profile-img.jpg";
        }
        else{
          $imageurl = "assets/img/".$row["file_name"];
          $finalpath_for_img = $imageurl;
        }

      ?>
      <li>
        <div class="profile-details">
          <div class="profile-content">
            <img src="<?php echo $finalpath_for_img?>"  alt="profileImg" />
          </div>
          <div class="name-job">
            <div class="profile_name"><?php echo $row['fName']?></div>
            <div class="job"><?php echo $row['user_type']; ?></div>
          </div>
          <a href="logout.php"><i class="bx bx-log-out"></i></a>
        </div>
      </li>
    </ul>
  </div>
  <?php
    }   
  ?>
  <!-- <script src="script.js"></script> -->

</body>
</html>
