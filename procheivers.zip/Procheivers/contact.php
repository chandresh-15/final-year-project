<?php
  if(isset($_POST['send']))
  {
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $email_sub = $_REQUEST['mail_subject'];
    $q_message = $_REQUEST['message'];
    $message='
    <html>
      <head>
        <title>Query Raised by '.$name.'</title>
      </head>
      <body>
        <h4>Name:'.$name.'</h4>
        <h4>Emailed-by:'.$email.'</h4>
        <h4>Subject:'.$email_sub.'</h4>
        <h4>Query:'.$q_message.'</h4>
      </body>
    </html>';
    include_once("SMTP/class.phpmailer.php");
    include_once("SMTP/class.smtp.php");
      // $email = $email; 
    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->SMTPAuth = true;                 
    $mail->SMTPSecure = "tls";      
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587; 
    $mail->Username = ('procheiver0210@gmail.com');   //Enter your username/emailid
    $mail->Password = "ajyuebsfxjzrrdvn";   //Enter your password
    $mail->FromName = $name;
    $mail->AddAddress('procheiver0210@gmail.com');
    $mail->Subject = $email_sub;
    $mail->isHTML( TRUE );
    $mail->Body =$message;
    if($mail->send())
    {
      echo '<script>alert("We have e-mailed to Admin!")</script>';
    }
    else
    {
      echo '<script>alert("We can`t find a user with that email address")</script>';
    }
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <title>Responsive Contact us Form</title>
    <link rel="stylesheet" href="contact.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-5">
          <h1 class="mb-5">Contact Us</h1>
          <!-- https://formsubmit.co/procheiver0210@gmail.com -->
            <div class="mb-3">
          <form action="" method="POST">
              <label class="form-label form-head">Full Name</label>
              <input name="name" type="text" class="form-control" id="text-css" required />
            </div>

            <div class="mb-3">
              <label class="form-label form-head">Email address</label>
              <input name="email" type="email" class="form-control" id="text-css" required />
              <div id="emailHelp" class="form-text">
                Don't worry, we won't share it with anyone else.
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label form-head">Email Subject</label>
              <input name="mail_subject" type="text" class="form-control" id="text-css"/>
              <div id="mail_subject" class="form-text">
                If you rather talk to a human directly.
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label form-head">Your Message</label>
              <textarea id="text-css" name="message" class="form-control" rows="3" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary" name="send">Submit</button>
          </form>
        </div>
        <div class="col-6 position-relative">
          <img src="contact.svg" class="w-75 position-absolute top-50 start-50 translate-middle"/>
        </div>
      </div>
    </div>
  </body>
</html>
