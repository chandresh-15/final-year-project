<?php
  include "config.php";
  if(isset($_REQUEST['send']))
  {
    $email = $_REQUEST['email'];
    $check_email = mysqli_query($conn,"select email from login_register_form where email='$email'");
    $res = mysqli_num_rows($check_email);
    if($res>0)
    {
      $message = 
      '<div>
        <p><b>Hello!</b></p>
        <p>You are recieving this email because we recieved a password reset request for your account.</p>
        <br>
        <p><button class="btn btn-primary"><a href="http://localhost/Procheivers/login/passwordreset.php?secret='.base64_encode($email).'">Reset Password</a></button></p>
        <br>
        <p>If you did not request a password reset, no further action is required.</p>
      </div>';


      include_once("SMTP/class.phpmailer.php");
      include_once("SMTP/class.smtp.php");
      $email = $email; 
      $mail = new PHPMailer;
      $mail->IsSMTP();
      $mail->SMTPAuth = true;                 
      $mail->SMTPSecure = "tls";      
      $mail->Host = 'smtp.gmail.com';
      $mail->Port = 587; 
      $mail->Username = "procheiver0210@gmail.com";   //Enter your username/emailid
      $mail->Password = "ajyuebsfxjzrrdvn";   //Enter your password
      $mail->FromName = "Chandresh";
      $mail->AddAddress($email);
      $mail->Subject = "Reset Password";
      $mail->isHTML( TRUE );
      $mail->Body =$message;
      if($mail->send())
      {
        echo '<script>alert("We have e-mailed your password reset link!")</script>';
      }
    }
    else
    {
      echo '<script>alert("We can`t find a user with that email address")</script>';
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Page</title>
  <script src="https://kit.fontawesome.com/aa64bf530b.js" crossorigin="anonymous"></script>
  <link href="recover.css" rel="stylesheet">
</head>
<body>
  <div class="admin-log">
    <img src="../procheiver-logo.png" height="70px" width="200px" style="margin-top: 20px;">
      <div class="login">
        <form action="" method="post">      
          <div class="container">
            <label><b>Email:</b></label>
              <i class="fa-solid fa-envelope"></i></i><input type="text" placeholder="abc01@gmail.com" name="email" required>
              <button type="submit" name="send" class="btn"> Send Mail </button>
          </div>
        </form>
      </div>
      <p class="error"><?php if(!empty($msg)){ echo $msg; } ?></p>
      <p class="text-center">Have an account? <a href="index.php">Log in</a></p>
  </div>
</body>
</html>