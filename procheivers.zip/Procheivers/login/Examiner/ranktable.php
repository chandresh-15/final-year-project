<?php 
    include 'config.php';
    include 'dashboard.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Questions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="addtest.css" rel="stylesheet"/>
    <link href="addcat.css" rel="stylesheet" />
    <link href="dashboard.css" rel="stylesheet"/>
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
</head>
<body>
    <section class="home-section">
        <div class="home-content">
            <i class="bx bx-menu"></i>
            <span class="text">Ranking List</span>
        </div>
        <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="examinerh.php">Home</a></li>
            <li class="breadcrumb-item"><a href="ranktable.php">Ranking List</a></li>
            <li class="breadcrumb-item active">Ranking List</li>
        </ol>
        </nav>
        <div class="container showlist">
            <div class="container-fluid list-data table-responsive mt-5">
                <table class="table table-hover table-bordered text-center">
                    <thead>
                        <tr>
                        <th>Ranking</th>
                        <th>User ID</th>
                        <th>quiz_name</th>
                        <th>marks_obtained</th>
                        </tr>
                    </thead>
                    <tbody class="scrollit">
                    <div > 
                        <?php 
                            $per_page = 5;
                            $start = 0;
                            $current_page=1;
                            $i = 1;
                            if(isset($_GET['start']))
                            {
                                $start=$_GET['start'];
                                if($start<=0){
                                    $start=0;
                                    $current_page=1;
                                }else{
                                    $current_page=$start;
                                    $start--;
                                    $start=$start*$per_page;
                                }
                            }
                            
                            $record = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `result` WHERE marks_obtained > 3 ORDER BY marks_obtained DESC  LIMIT $start, $per_page   "));
                            
                           $num_per_page = 05;
                           $pagi=ceil($record/$per_page);
                            $sql = "SELECT * FROM `result` WHERE marks_obtained > 3 ORDER BY marks_obtained DESC  LIMIT $start, $per_page ";
                           
                            $result = mysqli_query($conn, $sql);

                            $ranking = $start + 1;

                            if(mysqli_num_rows($result)>0)

                            {
                                foreach($result as $item)
                                {
                                    ?> 
                                    
                                    <tr>
                                        <td><?= $ranking ?></td>
                                        <td><?= $item['user_id'] ?></td>
                                        <td><?= $item['quiz_name'] ?></td>
                                        <td><?= $item['marks_obtained'] ?></td>
                                        <!-- <td>
                                        <form action="viewquestion.php" method="POST">
                                            <a href="viewquestion.php?id=<?= $item['quiz_name'];?>" class="btn btn-primary">View Questions</a>
                                        </form>        
                                        </td>    -->
                                    </tr>
                                   
                                    <?php
                                     $ranking++;
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="5">No record found!!</td>
                                </tr>
                                <?php
                            }
                            

                        ?>
                         </div>
                    </tbody>
                </table>
                <!-- pagination code -->
                <ul class="pagination pagination-lg  justify-content-center">
                    <?php 
                        for($i=1;$i<=$pagi;$i++)
                        {
                            $class='';
                            if($current_page==$i){
                                ?><li class="page-item active"><a class="page-link" href="javascript:void(0)"> <?php  echo $i;?></a></li><?php
                            }else{
                            ?>
                                <li class="page-item"><a class="page-link" href="?start=<?php echo $i?>"><?php echo $i?></a></li>
                            <?php
                            }
                            ?>
                            <?php 
                        } 
                    ?>
                </ul>
            </div>
        </div>
    </section>
    <script src="script.js"></script>
</body>
</html>
