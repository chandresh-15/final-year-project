<?php
       include "config.php";
       include 'Student_Test_dashboard.php';
      // $query = "SELECT * FROM quiz_name";
      // $res = mysqli_query($conn, $query);
      
      // while($results = mysqli_fetch_array($res)){

    //  session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<section class="home-section">
    <div class="home-content">
      <i class="bx bx-menu"></i>
      <span class="text">Take Quiz</span>
    </div>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../student.php">Home</a></li>
        <li class="breadcrumb-item"><a href="quiz_list.php">Take Quiz</a></li>
        <li class="breadcrumb-item active">Take Quiz</li>
      </ol>
    </nav>
<div class="container showlist">
        <div class="container-fluid list-data table-responsive">
          <table class="table table-hover table-bordered">
            <thead>
              <tr>
                <th>Quiz Name</th>
                <th>Time</th>
                <th>Start</th>
              </tr>
            </thead>
            <tbody>
            <?php
            
            $per_page = 5;
            $start = 0;
            $current_page=1;
            if(isset($_GET['start'])){
              $start=$_GET['start'];
              if($start<=0){
                $start=0;
                $current_page=1;
              }else{
                $current_page=$start;
                $start--;
                $start=$start*$per_page;
              }
            }
            $record = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `quiz_name`"));

            $num_per_page = 05;
            $pagi=ceil($record/$per_page);
            $sql = "SELECT * FROM quiz_name LIMIT $start, $per_page";
            $result = mysqli_query($conn, $sql);
            $i = 1;
            if(mysqli_num_rows($result)>0){
                while($item = mysqli_fetch_array($result)){
                  $_SESSION['id'] =  $item['quiz_id'];
                    ?>
                    <tr>
                        <td><?= $item['quiz_name']; ?></td>
                        <td><?= $item['Total_test_duration']; ?></td>
                        <td>
                        
                        <button
                          type="button"
                          id ="<?= $item['quiz_name']; ?>"
                          class="btn btn-primary btn-css editbutton"
                          data-bs-toggle="modal"
                          data-bs-target="#startquizmodal"
                          onclick = "take_quiz('<?= $item['quiz_name']; ?>', <?= $item['quiz_id']; ?>, <?= $item['Total_test_duration']; ?>, <?= $item['Total_test_marks']; ?>)"
                        > 
                          Start 
                        </button>
                       
                        </td>
      
                    </tr>
                    <div class="modal fade" id="startquizmodal">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Read Instructions carefully</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                        <form action="newquiz.php">
                            <ul>
                            <li>Complete your quiz in given time. After that, the form will be closed for you</li>
                            <li>Students who will not submit their answers in time will receive 0.</li>
                            <li>You can only submit your answers once. If you wish to pause the the quiz, please use the submit button.</li>
                            <li>Each question has its own grading points. After you submit your answers, we will evaluate your answers and let you know your grades later.</li>
                            <li>If you have any technical problem during the quiz, please take a screenshot or screen recording and send us.</li>
            
                            </ul>
                            <!-- <input type="hidden" id="quizname" value=""/> -->
                            <input type="radio" id="myRadio" name="test" required>I read and want to continue

                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Start Quiz</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
                    
                  <?php
                  $i++;
                }
            }
            else{
                ?>
                <tr>
                    <td colspan="5">No record found!!</td>
                </tr>
                <?php
            }

          function func($name){
                $_SESSION['dn_name'] = $name;
              }
            ?>
            </tbody>
             
          </table>
          
          <!-- pagination code -->
            <ul class="pagination pagination-lg  justify-content-center">
            <?php 
                for($i=1;$i<=$pagi;$i++){
                $class='';
                if($current_page==$i){
                  ?><li class="page-item active"><a class="page-link" href="javascript:void(0)"><?php echo $i?></a></li><?php
                }else{
                ?>
                  <li class="page-item"><a class="page-link" href="?start=<?php echo $i?>"><?php echo $i?></a></li>
                <?php
                }
                ?>
                  
              <?php } 
             
            ?>
        </div>
    <!-- <div class="container mt-3">
<table class="table table-hover">
    <thead>
      <tr>
        <th>Quiz Name</th>
        <th>Time</th>
        <th>Mark</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php //echo //$results['quiz_name'];?></td>
        <td><?php // echo //$results['Total_test_duration'];?></td>
        <td><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#startquizmodal">Start Exam</button></td>
      </tr>
    </tbody>
  </table>
</div>

<?php

//    }
?> -->

          <!-- <div class="modal fade" id="startquizmodal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Read Instructions carefully</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                    <form action="newquiz.php">
                        <ul>
                        <li>Complete your quiz in given time. After that, the form will be closed for you</li>
                        <li>Students who will not submit their answers in time will receive 0.</li>
                        <li>You can only submit your answers once. If you wish to pause the the quiz, please use the submit button.</li>
                        <li>Each question has its own grading points. After you submit your answers, we will evaluate your answers and let you know your grades later.</li>
                        <li>If you have any technical problem during the quiz, please take a screenshot or screen recording and send us.</li>
        
                        </ul>
                        <input type="hidden" id="quizname" value="<?php echo $item['quiz_name'];?>"/>
                        <input type="radio" id="myRadio" name="test" required>I read and want to continue

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Start Quiz</button>
                    </div>
                    </form>
                </div>
            </div>
        </div> -->
      </section>
        <script>
       function take_quiz(name,id,duration,total_mark){
    
        sessionStorage.setItem("quiz_name", name);
        sessionStorage.setItem("quiz_id", id);
        sessionStorage.setItem("duration" , duration);
        sessionStorage.setItem("total_marks", total_mark);
      }

     

        //     $(document).ready(function() {

        //     $.ajax({
        //         type: "POST",
        //         url: "result.php",
        //         data: {
        //         score: res_score,
        //         },
        //         cache: false,
        //         success: function() {
        //         alert("Your answer recorded succefully");
        //         window.location.href = "quiz_list.php";
        //         },
        //         error: function(xhr, status, error) {
        //         console.error(xhr);
        //         }
        //         });
        // })
          </script>
         <script src="script.js"></script>
</body>
</html>