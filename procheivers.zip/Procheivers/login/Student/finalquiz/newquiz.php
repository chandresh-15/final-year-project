<?php
   // include "config.php";
    // include "timer.php";
    include 'Student_Test_dashboard.php';

    // $quiz_name_for_query = "<script>sessionStorage.getItem('quiz_name');</script>";
    // $quiz_name_for_query = $_SESSION['dn_name'];
    // $res = mysqli_query($conn,"SELECT * FROM `$quiz_name_for_query`");
    // // $row = mysqli_fetch_array($res, MYSQLI_NUM);
    // // echo $row[2];
    // $val = mysqli_fetch_all($res, MYSQLI_ASSOC);
    // $val1 = json_encode($val);
  
    //print_r($val1);
    // echo count($val);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Test</title>
    <link href="newquiz.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<section class="home-section">
    <div class="home-content">
      <i class="bx bx-menu"></i>
      <span class="text">Dashboard</span>
    </div>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../student.php">Home</a></li>
        <li class="breadcrumb-item"><a href="newquiz.php">Quiz</a></li>
        <li class="breadcrumb-item active">Quiz</li>
      </ol>
    </nav>
    <div class="center">
        <div class="quiz-header">
            <h3 id="quiz_name">Quiz Name</h3>
        </div>
        <div class="quiz-timer" >
            <h3 id="timer">Quiz timer</h3>
        </div>
        <div class="quiz-remains">
            <h3 id="remaining_question">Quiz remaining</h3>
        </div>
        <div class="quiz-questions question">
          <h3>Questions</h3>
        </div>
        <div class="quiz-options">
          <input type="radio" id="ans1" class="answer" name="answer" >
          <label for="ans1" id="option1">HTML</label><br>
        </div>
        <div class="quiz-options">
          <input type="radio" id="ans2" class="answer"  name="answer" >
          <label for="ans2" id="option2">HTML</label><br>
        </div>
        <div class="quiz-options">
          <input type="radio" id="ans3" class="answer"  name="answer" >
          <label for="ans3" id="option3">HTML</label><br>
        </div>
        <div class="quiz-options">
          <input type="radio"  id="ans4"  class="answer"  name="answer">
          <label for="ans4" id="option4">HTML</label><br>
        </div>
        <div class="save-next">
          <button class="button-48" role="button" id="submit"><span class="text">Save & Next</span></button>
        </div>
    </div>
    <div id="showScore" class="scoreArea" style="visibility : hidden;"></div>

</section>

<script>

var res ;
    $(document).ready(function(){
    var quiz_name_forQ = sessionStorage.getItem('quiz_name');
    $.ajax({
        async: false,
        url: 'takename.php',
        type: 'POST',
        dataType: 'JSON',
        data: {
            quiz_name : quiz_name_forQ,
        },
        success: function(response){
              res = response;
           // res.push(response);
            //var quizDB = res;
        }, error : function(req, err) {
            alert("No database found");
            window.location.href = "quiz_list.php";
        }
        });
 
    // const quizDB = <?php //print_r($val1); ?>;
    const quizDB = res;
    
//   console.log(quizDB);
const quiz_name = document.querySelector('#quiz_name');
const question = document.querySelector('.question');
const option1 = document.querySelector('#option1');
const option2 = document.querySelector('#option2');
const option3 = document.querySelector('#option3');
const option4 = document.querySelector('#option4');
const submit = document.querySelector('#submit');
const answers = document.querySelectorAll('.answer');
const showScore = document.querySelector('#showScore');
const remaining_question = document.querySelector('#remaining_question');

quiz_name.innerHTML = sessionStorage.getItem("quiz_name");

let questionCount = 0;
let score = 0;

const loadquestion = () => {
    const questionlist = quizDB[questionCount];
    question.innerHTML = questionlist.questions;
    option1.innerHTML = questionlist.option_1;
    option2.innerHTML = questionlist.option_2;
    option3.innerHTML = questionlist.option_3;
    option4.innerHTML = questionlist.option_4;
}
loadquestion();


const getCheckAnswer = () =>{
    let answer;
    answers.forEach((curAnsElem) => {
      console.log(curAnsElem);
        if(curAnsElem.checked){
            answer = curAnsElem.id;
        }
        
    })
    console.log(answer);
    return answer;//loop complete hogaya isliyeh answer return hua
}
const deselectAll  = () =>{
    answers.forEach((curAnsElem) => {
        curAnsElem.checked = false
    });
}


//globally defined value
var user_id_res = <?php echo $_SESSION['user_id'];?>;

var quiz_name_res = sessionStorage.getItem("quiz_name");
var quiz_id_res = sessionStorage.getItem("quiz_id");
var total_marks_res = sessionStorage.getItem("total_marks");


remaining_question.innerHTML = `<h3>${questionCount}/${quizDB.length}</h3>`
submit.addEventListener('click',()=>{
    
    const checkAnswer = getCheckAnswer();
    console.log(checkAnswer);

    console.log(quizDB[questionCount].correct_option);

    if(checkAnswer === quizDB[questionCount].correct_option){
        score++;
    };

     
    questionCount++;

    deselectAll();

    if(questionCount < quizDB.length){
        loadquestion();
    }
    else{

        document.getElementById("submit").innerHTML = "Timer over";
        clearInterval(timerID); 
        localStorage.removeItem('saved_timer');

        // var user_id_res = <?php //echo $_SESSION['user_id'];?>;
        var res_score  =  score;
        // var quiz_name_res = sessionStorage.getItem("quiz_name");
        // var quiz_id_res = sessionStorage.getItem("quiz_id");

        $(document).ready(function() {
            $.ajax({
                type: "POST",
                url: "result.php",
                data: {
                score: res_score,
                user_id : user_id_res,
                quiz_name : quiz_name_res,
                quiz_id : quiz_id_res,
                total_mark : total_marks_res,
                },
                cache: false,
                success: function() {
                alert("Your answer recorded succefully");
                window.location.href = "quiz_list.php";
                sessionStorage.removeItem("quiz_id");
                sessionStorage.removeItem("quiz_name");
                sessionStorage.removeItem("duration");
                sessionStorage.removeItem("total_marks");
                },
                error: function(xhr, status, error) {
                console.error(xhr);
                }
                });
        })
        // window.location.href = "result.php";
        // showScore.innerHTML = `
        //     <h3> you scored ${score}/${quizDB.length}</h3>
        // `
        // alert(${score}/${quizDB.length}</h3>);
    }

    remaining_question.innerHTML = `<h3>${questionCount}/${quizDB.length}</h3>`
})

// script for timmer
            const timerValue = sessionStorage.getItem("duration"); // this value is in seconds and comes from quiz_list ka click pe
		    let time = localStorage.getItem('saved_timer');
		    if(time == null) {
		        const saved_timer = new Date().getTime() + (timerValue * 1000);
		        localStorage.setItem('saved_timer', saved_timer);
		        time = saved_timer;
		    }
		    
		        const timerID = setInterval(() => {
		        const now = new Date().getTime();
		        const difference = time - now;
		        
		        
		        const totalSeconds = Math.floor(difference/1000);
				const hours = Math.floor(timerValue/3600);
		        const minutes = Math.floor(totalSeconds / 60);
		        const seconds = totalSeconds % 60;
		        document.querySelector("#timer").innerText = hours +':'+ minutes + ':' + ((seconds < 10) ? '0' + seconds : seconds);
		        
		        if(totalSeconds <= 0) {
		            clearInterval(timerID);
		            localStorage.removeItem('saved_timer');
					var res_score  =   score;
                    $(document).ready(function() {
                    $.ajax({
                        type: "POST",
                        url: "result.php",
                        data: {
                            score: res_score,   
                            user_id : user_id_res,
                            quiz_name : quiz_name_res,
                            quiz_id : quiz_id_res,
                            total_mark : total_marks_res,
                        },
                        cache: false,
                        success: function() {
                        alert("Times UP !! Your answer recorded succefully");
                        window.location.href = "quiz_list.php";
                        sessionStorage.removeItem("quiz_id");
                        sessionStorage.removeItem("quiz_name");
                        sessionStorage.removeItem("duration");
                        sessionStorage.removeItem("total_marks");
                        },
                        error: function(xhr, status, error) {
                        console.error(xhr);
                        }
                        });
                })
		        }
		    }, 10);

        });
		// 	function redirect(){
        //     document.getElementById("submit").innerHTML = "Timer over";
        //     clearInterval(timerID); 
        //     localStorage.removeItem('saved_timer');
		// 	window.location.href = 'result.php';
        // }


</script>
<!-- script for timmer  -->
<!-- <script>
		    const timerValue = 30; // this value is in seconds
		    let time = localStorage.getItem('saved_timer');
		    if(time == null) {
		        const saved_timer = new Date().getTime() + (timerValue * 1000);
		        localStorage.setItem('saved_timer', saved_timer);
		        time = saved_timer;
		    }
		    
		    const timerID = setInterval(() => {
		        const now = new Date().getTime();
		        const difference = time - now;
		        
		        
		        const totalSeconds = Math.floor(difference/1000);
				const hours = Math.floor(timerValue/3600);
		        const minutes = Math.floor(totalSeconds / 60);
		        const seconds = totalSeconds % 60;
		        document.querySelector("#timer").innerText = hours +':'+ minutes + ':' + ((seconds < 10) ? '0' + seconds : seconds);
		        
		        if(totalSeconds <= 0) {
		            clearInterval(timerID);
		            localStorage.removeItem('saved_timer');
					
                    $(document).ready(function() {
                    $.ajax({
                        type: "POST",
                        url: "result.php",
                        data: {
                        score: res_score,
                        },
                        cache: false,
                        success: function() {
                        alert("Your answer recorded succefully");
                        window.location.href = "quiz_list.php";
                        },
                        error: function(xhr, status, error) {
                        console.error(xhr);
                        }
                        });
                })
		        }
		    }, 10);

		// 	function redirect(){
        //     document.getElementById("submit").innerHTML = "Timer over";
        //     clearInterval(timerID); 
        //     localStorage.removeItem('saved_timer');
		// 	window.location.href = 'result.php';
        // }
		</script> -->
        <script src="script.js"></script>

</body>
</html>