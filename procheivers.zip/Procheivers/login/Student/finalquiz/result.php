<?php 
    include 'Student_Test_dashboard.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result</title>
    <script src=
        "https://code.jquery.com/jquery-3.6.0.min.js" 
        integrity=
"sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" 
        crossorigin="anonymous">
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<section class="home-section">
    <div class="home-content">
      <i class="bx bx-menu"></i>
      <span class="text">Dashboard</span>
    </div>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../student.php">Home</a></li>
        <li class="breadcrumb-item"><a href="result.php">Result</a></li>
        <li class="breadcrumb-item active">Result</li>
      </ol>
    </nav>
    <?php
        include "config.php";
        $score =  $_POST['score'];
        $user_id = $_POST['user_id'];
        $quiz_name = $_POST['quiz_name'];
        $quiz_id = $_POST['quiz_id'];
        $total_mark = $_POST['total_mark'];

        $sql = "INSERT INTO result (marks_obtained, user_id, quiz_name, quiz_id, total_test_marks) VALUES ($score, $user_id, '$quiz_name',$quiz_id, $total_mark)";
        $res = mysqli_query($conn, $sql);

        if($res){
          echo "ok";
        }
        else{
          echo "<ecript>alert('error')</script>";
        }
            
    ?>
    </section>
    <script>
    $(document).ready(function() {
            function disableBack() {
                window.history.forward()
            }
            window.onload = disableBack();
            window.onpageshow = function(e) {
                if (e.persisted)
                    disableBack();
            }
        });
    </script>
     <script src="script.js"></script>
</body>
</html>