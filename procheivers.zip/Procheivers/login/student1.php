<?php
     include "config.php";
     session_start();
    if(!isset($_SESSION['isUserLoggedin'])){
        echo "<script>window.location.href='index.php?user_not_logged_in';</script>";
    }
    if($_SESSION['usertype']!= 'Student'){
        echo "<script>window.location.href='index.php';</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student dashboard </title>
</head>
<body>
    <h1>you logged in as a Student</h1>
    <h2><?= $_SESSION['emailId']?></h2>
    <a href="logout.php">Logout</a>
</body>
</html>