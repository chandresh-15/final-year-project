<?php
    include "config.php";
    session_start();
    $userid = $_SESSION['user_id'];

    $query = "UPDATE login_register_form SET file_name = NULL WHERE id = $userid";
    $result = mysqli_query($conn, $query);

    if($result) 
    {
        echo "<script>alert('Profile deleted Successfully'); window.location = 'users-profile.php'</script>";
        // header("Location: questions.php");

    }
    else
    {
        echo "<script>alert('Facing an Error Please Try Again!!'); window.location = 'users-profile.php'</script>";
        // echo "<script>alert('some error')</script>";
        // header("Location: questions.php");

    }   

?>